-keepattributes *Annotation*
-keepclassmembers class * {
    @androidx.annotation.Keep <methods>;
}

# Keep Media3 ExoPlayer classes used via reflection
-keep class androidx.media3.exoplayer.** { *; }
-keep class androidx.media3.ui.** { *; }
-dontwarn androidx.media3.**

# Keep Coil3 decoders
-keep class coil3.video.** { *; }
-dontwarn coil3.**
