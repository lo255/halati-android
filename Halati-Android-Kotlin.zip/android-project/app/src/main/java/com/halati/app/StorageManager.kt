package com.halati.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import androidx.documentfile.provider.DocumentFile
import java.io.File

class StorageManager(
    private val context: Context,
    private val permissionManager: PermissionManager
) {
    private val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun saveSafTreeUri(source: StatusSourceType, treeUri: Uri) {
        val flags = Intent.FLAG_GRANT_READ_URI_PERMISSION
        try {
            context.contentResolver.takePersistableUriPermission(treeUri, flags)
        } catch (_: SecurityException) {
            // Best-effort if provider already persisted or rejected non-persistable flag
        }
        prefs.edit().putString(safKey(source), treeUri.toString()).apply()
    }

    fun clearSafTreeUri(source: StatusSourceType) {
        val uri = getSavedSafTreeUri(source)
        if (uri != null) {
            try {
                context.contentResolver.releasePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: SecurityException) {
                // Ignore if already revoked by system
            }
        }
        prefs.edit().remove(safKey(source)).apply()
    }

    fun getSavedSafTreeUri(source: StatusSourceType): Uri? {
        val raw = prefs.getString(safKey(source), null) ?: return null
        val parsed = runCatching { Uri.parse(raw) }.getOrNull() ?: return null
        val isPersisted = context.contentResolver.persistedUriPermissions.any { permission ->
            permission.uri == parsed && permission.isReadPermission
        }
        if (!isPersisted) {
            prefs.edit().remove(safKey(source)).apply()
            return null
        }
        return parsed
    }

    fun getAutoRefreshOnLaunch(): Boolean {
        return prefs.getBoolean(KEY_AUTO_REFRESH, true)
    }

    fun setAutoRefreshOnLaunch(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_AUTO_REFRESH, enabled).apply()
    }

    fun resolveAccessMode(source: StatusSourceType): AccessMode {
        if (getSavedSafTreeUri(source) != null) {
            return AccessMode.SAF_PERSISTED
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R && permissionManager.hasAllFilesAccess()) {
            return AccessMode.DIRECT_ALL_FILES
        }
        if (Build.VERSION.SDK_INT == Build.VERSION_CODES.Q && permissionManager.isLegacyReadGranted()) {
            return AccessMode.LEGACY_STORAGE
        }
        return AccessMode.NONE
    }

    fun resolveSafStatusesDirectory(source: StatusSourceType): DocumentFile? {
        val treeUri = getSavedSafTreeUri(source) ?: return null
        val root = DocumentFile.fromTreeUri(context, treeUri) ?: return null
        if (!root.exists() || !root.isDirectory || !root.canRead()) {
            return null
        }

        // Case 1: User picked the .Statuses folder directly
        if (root.name.equals(STATUSES_FOLDER_NAME, ignoreCase = true)) {
            return root
        }

        // Case 2: User picked a parent folder such as Media or WhatsApp or Android/media/com.whatsapp
        val directChild = root.findFile(STATUSES_FOLDER_NAME)
        if (directChild != null && directChild.isDirectory && directChild.canRead()) {
            return directChild
        }

        val relativeChain = when (source) {
            StatusSourceType.WHATSAPP -> listOf("WhatsApp", "Media", STATUSES_FOLDER_NAME)
            StatusSourceType.WHATSAPP_BUSINESS -> listOf("WhatsApp Business", "Media", STATUSES_FOLDER_NAME)
        }

        var cursor: DocumentFile? = root
        for (segment in relativeChain) {
            val next = cursor?.findFile(segment)
            if (next != null) {
                cursor = next
            } else if (cursor?.name.equals(segment, ignoreCase = true)) {
                continue
            } else {
                cursor = null
                break
            }
        }
        if (cursor != null && cursor.isDirectory && cursor.canRead()) {
            return cursor
        }

        // Case 3: User selected Android/media root
        val pkgDir = root.findFile(source.packageName)
        if (pkgDir != null && pkgDir.isDirectory) {
            var deep: DocumentFile? = pkgDir
            for (segment in relativeChain) {
                deep = deep?.findFile(segment)
            }
            if (deep != null && deep.isDirectory && deep.canRead()) {
                return deep
            }
        }

        // Case 4: User selected Media folder directly
        val mediaChild = root.findFile("Media")?.findFile(STATUSES_FOLDER_NAME)
        if (mediaChild != null && mediaChild.isDirectory && mediaChild.canRead()) {
            return mediaChild
        }

        return null
    }

    fun resolveDirectStatusesDirectory(source: StatusSourceType): File? {
        @Suppress("DEPRECATION")
        val externalRoot = Environment.getExternalStorageDirectory() ?: return null
        val candidates = listOf(
            File(externalRoot, source.scopedRelativePath),
            File(externalRoot, source.legacyRelativePath)
        )
        return candidates.firstOrNull { dir ->
            dir.exists() && dir.isDirectory && dir.canRead()
        }
    }

    private fun safKey(source: StatusSourceType): String = "saf_uri_${source.name}"

    companion object {
        private const val PREFS_NAME = "halati_storage_prefs"
        private const val KEY_AUTO_REFRESH = "auto_refresh_on_launch"
        const val STATUSES_FOLDER_NAME = ".Statuses"
    }
}
