package com.halati.app

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.webkit.MimeTypeMap
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale

class StatusScanner(
    private val context: Context,
    private val storageManager: StorageManager,
    private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO
) {

    suspend fun scanSource(
        source: StatusSourceType,
        isAppInstalled: Boolean
    ): SourceScanResult = withContext(ioDispatcher) {
        val accessMode = storageManager.resolveAccessMode(source)

        if (accessMode == AccessMode.SAF_PERSISTED) {
            val safDir = storageManager.resolveSafStatusesDirectory(source)
            if (safDir == null) {
                return@withContext SourceScanResult(
                    source = source,
                    accessState = SourceAccessState.NEEDS_FOLDER_PERMISSION,
                    accessMode = AccessMode.NONE,
                    errorMessage = "تعذّر الوصول إلى مجلد حالات ${source.displayNameAr}. يرجى تحديد المجلد مرة أخرى."
                )
            }
            val items = scanDocumentDirectory(safDir, source)
            return@withContext if (items.isEmpty()) {
                SourceScanResult(
                    source = source,
                    accessState = SourceAccessState.FOLDER_NOT_FOUND_OR_EMPTY,
                    accessMode = AccessMode.SAF_PERSISTED,
                    items = emptyList(),
                    resolvedPathLabel = safDir.name ?: source.scopedRelativePath
                )
            } else {
                SourceScanResult(
                    source = source,
                    accessState = SourceAccessState.READY,
                    accessMode = AccessMode.SAF_PERSISTED,
                    items = items,
                    resolvedPathLabel = safDir.name ?: source.scopedRelativePath
                )
            }
        }

        if (accessMode == AccessMode.DIRECT_ALL_FILES || accessMode == AccessMode.LEGACY_STORAGE) {
            val directDir = storageManager.resolveDirectStatusesDirectory(source)
            if (directDir == null) {
                val state = if (!isAppInstalled) {
                    SourceAccessState.APP_NOT_INSTALLED
                } else {
                    SourceAccessState.FOLDER_NOT_FOUND_OR_EMPTY
                }
                return@withContext SourceScanResult(
                    source = source,
                    accessState = state,
                    accessMode = accessMode,
                    items = emptyList(),
                    resolvedPathLabel = source.scopedRelativePath
                )
            }
            val items = scanFileDirectory(directDir, source)
            return@withContext if (items.isEmpty()) {
                SourceScanResult(
                    source = source,
                    accessState = SourceAccessState.FOLDER_NOT_FOUND_OR_EMPTY,
                    accessMode = accessMode,
                    items = emptyList(),
                    resolvedPathLabel = directDir.absolutePath
                )
            } else {
                SourceScanResult(
                    source = source,
                    accessState = SourceAccessState.READY,
                    accessMode = accessMode,
                    items = items,
                    resolvedPathLabel = directDir.absolutePath
                )
            }
        }

        if (!isAppInstalled) {
            return@withContext SourceScanResult(
                source = source,
                accessState = SourceAccessState.APP_NOT_INSTALLED,
                accessMode = AccessMode.NONE
            )
        }

        SourceScanResult(
            source = source,
            accessState = SourceAccessState.NEEDS_FOLDER_PERMISSION,
            accessMode = AccessMode.NONE
        )
    }

    internal fun scanDocumentDirectory(
        directory: DocumentFile,
        source: StatusSourceType
    ): List<StatusItem> {
        val children = directory.listFiles()
        if (children.isEmpty()) return emptyList()

        return children.mapNotNull { file ->
            if (file.isDirectory) return@mapNotNull null
            val name = file.name ?: return@mapNotNull null
            if (!isSupportedVisibleMediaName(name)) return@mapNotNull null
            val size = file.length()
            if (size <= 0L) return@mapNotNull null

            val resolvedMime = resolveMimeType(name, file.type) ?: return@mapNotNull null
            val mediaType = classifyMediaType(name, resolvedMime) ?: return@mapNotNull null
            val uri = file.uri
            val duration = if (mediaType == MediaType.VIDEO) extractVideoDuration(uri) else 0L

            StatusItem(
                id = "${source.name}_$name",
                uri = uri,
                fileName = name,
                mimeType = resolvedMime,
                mediaType = mediaType,
                source = source,
                sizeBytes = size,
                lastModifiedMillis = file.lastModified(),
                durationMillis = duration
            )
        }.sortedByDescending { it.lastModifiedMillis }
    }

    internal fun scanFileDirectory(
        directory: File,
        source: StatusSourceType
    ): List<StatusItem> {
        val children = directory.listFiles() ?: return emptyList()
        if (children.isEmpty()) return emptyList()

        return children.mapNotNull { file ->
            if (!file.isFile || !file.canRead()) return@mapNotNull null
            val name = file.name
            if (!isSupportedVisibleMediaName(name)) return@mapNotNull null
            val size = file.length()
            if (size <= 0L) return@mapNotNull null

            val resolvedMime = resolveMimeType(name, null) ?: return@mapNotNull null
            val mediaType = classifyMediaType(name, resolvedMime) ?: return@mapNotNull null
            val uri = Uri.fromFile(file)
            val duration = if (mediaType == MediaType.VIDEO) extractVideoDuration(uri) else 0L

            StatusItem(
                id = "${source.name}_$name",
                uri = uri,
                fileName = name,
                mimeType = resolvedMime,
                mediaType = mediaType,
                source = source,
                sizeBytes = size,
                lastModifiedMillis = file.lastModified(),
                durationMillis = duration
            )
        }.sortedByDescending { it.lastModifiedMillis }
    }

    private fun extractVideoDuration(uri: Uri): Long {
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(context, uri)
            retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                ?.toLongOrNull() ?: 0L
        } catch (_: Exception) {
            0L
        } finally {
            runCatching { retriever.release() }
        }
    }

    companion object {
        private val IMAGE_EXTENSIONS = setOf("jpg", "jpeg", "png", "webp", "heic", "heif")
        private val VIDEO_EXTENSIONS = setOf("mp4", "3gp", "mkv", "webm", "mov")

        fun isSupportedVisibleMediaName(fileName: String): Boolean {
            if (fileName.isBlank()) return false
            if (fileName.startsWith(".")) return false
            if (fileName.equals("nomedia", ignoreCase = true)) return false
            val ext = fileName.substringAfterLast('.', "").lowercase(Locale.ROOT)
            return ext in IMAGE_EXTENSIONS || ext in VIDEO_EXTENSIONS
        }

        fun resolveMimeType(fileName: String, providerMime: String?): String? {
            if (!providerMime.isNullOrBlank() &&
                (providerMime.startsWith("image/") || providerMime.startsWith("video/"))
            ) {
                return providerMime
            }
            val ext = fileName.substringAfterLast('.', "").lowercase(Locale.ROOT)
            val systemMime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext)
            if (!systemMime.isNullOrBlank()) return systemMime
            return when (ext) {
                "jpg", "jpeg" -> "image/jpeg"
                "png" -> "image/png"
                "webp" -> "image/webp"
                "heic", "heif" -> "image/heic"
                "mp4" -> "video/mp4"
                "3gp" -> "video/3gpp"
                "mkv" -> "video/x-matroska"
                "webm" -> "video/webm"
                "mov" -> "video/quicktime"
                else -> null
            }
        }

        fun classifyMediaType(fileName: String, mimeType: String): MediaType? {
            val ext = fileName.substringAfterLast('.', "").lowercase(Locale.ROOT)
            return when {
                mimeType.startsWith("image/") || ext in IMAGE_EXTENSIONS -> MediaType.IMAGE
                mimeType.startsWith("video/") || ext in VIDEO_EXTENSIONS -> MediaType.VIDEO
                else -> null
            }
        }
    }
}
