package com.halati.app

import android.net.Uri
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Videocam
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil3.compose.AsyncImage
import coil3.request.ImageRequest
import coil3.request.crossfade
import coil3.video.VideoFrameDecoder
import coil3.video.videoFrameMillis
import java.util.Locale

@Composable
fun HalatiTopBar(
    title: String,
    subtitle: String? = null,
    isScanning: Boolean,
    onRefreshClick: () -> Unit
) {
    Surface(
        color = HalatiColors.PitchBlack,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.headlineMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (!subtitle.isNullOrBlank()) {
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = subtitle,
                            style = MaterialTheme.typography.labelMedium,
                            color = HalatiColors.TextSecondary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
                IconButton(
                    onClick = onRefreshClick,
                    enabled = !isScanning
                ) {
                    if (isScanning) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(20.dp),
                            strokeWidth = 2.dp,
                            color = HalatiColors.EmeraldPrimary
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Rounded.Refresh,
                            contentDescription = "تحديث الحالات",
                            tint = HalatiColors.EmeraldPrimary
                        )
                    }
                }
            }
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(1.dp)
                    .background(HalatiColors.HairlineBorder)
            )
        }
    }
}

@Composable
fun MediaTypeSegmentedToggle(
    selectedType: MediaType,
    imageCount: Int,
    videoCount: Int,
    onSelect: (MediaType) -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = HalatiColors.SurfaceDark,
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, HalatiColors.HairlineBorder),
        modifier = modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(4.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            MediaTypeSegmentButton(
                label = "الصور ($imageCount)",
                icon = Icons.Rounded.Image,
                selected = selectedType == MediaType.IMAGE,
                onClick = { onSelect(MediaType.IMAGE) },
                modifier = Modifier.weight(1f)
            )
            MediaTypeSegmentButton(
                label = "الفيديوهات ($videoCount)",
                icon = Icons.Rounded.Videocam,
                selected = selectedType == MediaType.VIDEO,
                onClick = { onSelect(MediaType.VIDEO) },
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
private fun MediaTypeSegmentButton(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val container = if (selected) HalatiColors.EmeraldPrimary else Color.Transparent
    val content = if (selected) Color(0xFF031A11) else HalatiColors.TextSecondary

    Surface(
        onClick = onClick,
        color = container,
        shape = RoundedCornerShape(10.dp),
        modifier = modifier.height(42.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxSize(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = content,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = label,
                color = content,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun StatusThumbnailGridCard(
    uri: Uri,
    mediaType: MediaType,
    sizeBytes: Long,
    durationMillis: Long,
    isSaved: Boolean,
    isSelected: Boolean,
    selectionMode: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    onQuickActionClick: (() -> Unit)? = null
) {
    val context = LocalContext.current
    val borderColor = if (isSelected) HalatiColors.EmeraldPrimary else HalatiColors.HairlineBorder
    val borderWidth = if (isSelected) 2.dp else 1.dp

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(0.76f)
            .clip(RoundedCornerShape(16.dp))
            .background(HalatiColors.SurfaceDark)
            .border(borderWidth, borderColor, RoundedCornerShape(16.dp))
            .combinedClickable(
                onClick = onClick,
                onLongClick = onLongClick
            )
    ) {
        AsyncImage(
            model = ImageRequest.Builder(context)
                .data(uri)
                .apply {
                    if (mediaType == MediaType.VIDEO) {
                        decoderFactory(VideoFrameDecoder.Factory())
                        videoFrameMillis(800L)
                    }
                    crossfade(true)
                }
                .build(),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(64.dp)
                .align(Alignment.BottomCenter)
                .background(
                    Brush.verticalGradient(
                        colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.85f))
                    )
                )
        )

        if (mediaType == MediaType.VIDEO) {
            Box(
                modifier = Modifier
                    .align(Alignment.Center)
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(Color.Black.copy(alpha = 0.65f))
                    .border(1.dp, Color.White.copy(alpha = 0.25f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Rounded.PlayArrow,
                    contentDescription = "تشغيل الفيديو",
                    tint = Color.White,
                    modifier = Modifier.size(26.dp)
                )
            }
        }

        if (selectionMode || isSelected) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(8.dp)
                    .size(26.dp)
                    .clip(CircleShape)
                    .background(
                        if (isSelected) HalatiColors.EmeraldPrimary else Color.Black.copy(alpha = 0.55f)
                    )
                    .border(
                        width = 1.5.dp,
                        color = if (isSelected) HalatiColors.EmeraldPrimary else Color.White.copy(alpha = 0.65f),
                        shape = CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                if (isSelected) {
                    Icon(
                        imageVector = Icons.Rounded.CheckCircle,
                        contentDescription = "محدد",
                        tint = Color(0xFF031A11),
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        } else if (isSaved) {
            Surface(
                color = HalatiColors.EmeraldDeep.copy(alpha = 0.92f),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(8.dp)
            ) {
                Text(
                    text = "محفوظ",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color(0xFFA7F3D0),
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                )
            }
        }

        Row(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                if (mediaType == MediaType.VIDEO && durationMillis > 0L) {
                    Text(
                        text = formatDurationArabic(durationMillis),
                        style = MaterialTheme.typography.labelMedium,
                        color = Color.White,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1
                    )
                }
                Text(
                    text = formatFileSizeArabic(sizeBytes),
                    style = MaterialTheme.typography.labelSmall,
                    color = Color.White.copy(alpha = 0.8f),
                    maxLines = 1
                )
            }

            if (!selectionMode && onQuickActionClick != null) {
                Surface(
                    onClick = onQuickActionClick,
                    color = if (isSaved) HalatiColors.SurfaceElevated else HalatiColors.EmeraldPrimary,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.size(34.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = if (isSaved) Icons.Rounded.CheckCircle else Icons.Rounded.Download,
                            contentDescription = if (isSaved) "محفوظ مسبقاً" else "حفظ الحالة",
                            tint = if (isSaved) HalatiColors.EmeraldPrimary else Color(0xFF031A11),
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun PermissionGuideCard(
    source: StatusSourceType,
    onGrantSafClick: () -> Unit,
    onOpenAllFilesSettings: () -> Unit
) {
    Surface(
        color = HalatiColors.SurfaceDark,
        shape = RoundedCornerShape(20.dp),
        border = BorderStroke(1.dp, HalatiColors.HairlineBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(HalatiColors.EmeraldDeep.copy(alpha = 0.45f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Rounded.FolderOpen,
                        contentDescription = null,
                        tint = HalatiColors.EmeraldPrimary
                    )
                }
                Column {
                    Text(
                        text = "منح صلاحية مجلد ${source.displayNameAr}",
                        style = MaterialTheme.typography.titleMedium
                    )
                    Text(
                        text = "يتم حفظ الإذن تلقائياً ولن يُطلب منك مجدداً",
                        style = MaterialTheme.typography.labelSmall
                    )
                }
            }

            Text(
                text = "بسبب قيود Scoped Storage في Android 10–16، يقع مجلد الحالات في المسار المخفي:\n${source.scopedRelativePath}\nاختر «استخدام هذا المجلد» في نافذة النظام لمنح وصول دائم ومباشر.",
                style = MaterialTheme.typography.bodyMedium,
                color = HalatiColors.TextSecondary
            )

            Button(
                onClick = onGrantSafClick,
                colors = ButtonDefaults.buttonColors(
                    containerColor = HalatiColors.EmeraldPrimary,
                    contentColor = Color(0xFF031A11)
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
            ) {
                Text(
                    text = "تحديد مجلد حالات ${source.displayNameAr} (SAF)",
                    fontWeight = FontWeight.Bold
                )
            }

            OutlinedButton(
                onClick = onOpenAllFilesSettings,
                border = BorderStroke(1.dp, HalatiColors.HairlineBorder),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(44.dp)
            ) {
                Text(
                    text = "أو تفعيل الوصول المباشر للملفات من الإعدادات",
                    color = HalatiColors.TextPrimary,
                    style = MaterialTheme.typography.labelMedium
                )
            }
        }
    }
}

@Composable
fun EmptyStatusState(
    title: String,
    description: String,
    actionLabel: String? = null,
    onActionClick: (() -> Unit)? = null
) {
    Surface(
        color = HalatiColors.SurfaceDark,
        shape = RoundedCornerShape(20.dp),
        border = BorderStroke(1.dp, HalatiColors.HairlineBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp, vertical = 32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                textAlign = TextAlign.Center
            )
            Text(
                text = description,
                style = MaterialTheme.typography.bodyMedium,
                color = HalatiColors.TextSecondary,
                textAlign = TextAlign.Center
            )
            if (!actionLabel.isNullOrBlank() && onActionClick != null) {
                Spacer(modifier = Modifier.height(6.dp))
                OutlinedButton(
                    onClick = onActionClick,
                    border = BorderStroke(1.dp, HalatiColors.EmeraldPrimary),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(text = actionLabel, color = HalatiColors.EmeraldPrimary)
                }
            }
        }
    }
}

@Composable
fun ErrorBanner(
    message: String,
    onDismiss: () -> Unit
) {
    Surface(
        color = HalatiColors.DangerRed.copy(alpha = 0.14f),
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, HalatiColors.DangerRed.copy(alpha = 0.45f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Icon(
                imageVector = Icons.Rounded.WarningAmber,
                contentDescription = null,
                tint = HalatiColors.DangerRed
            )
            Text(
                text = message,
                style = MaterialTheme.typography.bodyMedium,
                color = HalatiColors.TextPrimary,
                modifier = Modifier.weight(1f)
            )
            OutlinedButton(
                onClick = onDismiss,
                border = BorderStroke(1.dp, HalatiColors.DangerRed.copy(alpha = 0.5f)),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text(text = "إغلاق", color = HalatiColors.TextPrimary, style = MaterialTheme.typography.labelMedium)
            }
        }
    }
}

fun formatFileSizeArabic(bytes: Long): String {
    if (bytes <= 0L) return "0 ك.ب"
    val kb = bytes / 1024.0
    if (kb < 1024.0) {
        return String.format(Locale.US, "%.0f ك.ب", kb)
    }
    val mb = kb / 1024.0
    return String.format(Locale.US, "%.1f م.ب", mb)
}

fun formatDurationArabic(millis: Long): String {
    if (millis <= 0L) return "00:00"
    val totalSeconds = millis / 1000L
    val minutes = totalSeconds / 60L
    val seconds = totalSeconds % 60L
    return String.format(Locale.US, "%02d:%02d", minutes, seconds)
}
