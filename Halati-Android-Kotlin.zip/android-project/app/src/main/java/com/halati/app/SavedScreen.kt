package com.halati.app

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@Composable
fun SavedScreen(
    savedItems: List<SavedMediaItem>,
    selectedMediaType: MediaType,
    selectedIds: Set<Long>,
    hasGalleryPermission: Boolean,
    onSelectMediaType: (MediaType) -> Unit,
    onRequestGalleryPermission: () -> Unit,
    onItemClick: (SavedMediaItem) -> Unit,
    onItemLongClick: (SavedMediaItem) -> Unit,
    onDeleteSelected: (List<SavedMediaItem>) -> Unit,
    onClearSelection: () -> Unit
) {
    val images = savedItems.filter { it.mediaType == MediaType.IMAGE }
    val videos = savedItems.filter { it.mediaType == MediaType.VIDEO }
    val visibleItems = if (selectedMediaType == MediaType.IMAGE) images else videos
    val selectionMode = selectedIds.isNotEmpty()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(HalatiColors.PitchBlack)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (!hasGalleryPermission) {
                EmptyStatusState(
                    title = "إذن قراءة معرض الصور والفيديو مطلوب",
                    description = "لعرض الملفات المحفوظة في مجلد Halati داخل معرض الهاتف وإدارتها، يرجى منح إذن الوسائط.",
                    actionLabel = "منح إذن المعرض",
                    onActionClick = onRequestGalleryPermission
                )
            } else {
                MediaTypeSegmentedToggle(
                    selectedType = selectedMediaType,
                    imageCount = images.size,
                    videoCount = videos.size,
                    onSelect = onSelectMediaType
                )

                if (visibleItems.isEmpty()) {
                    EmptyStatusState(
                        title = if (selectedMediaType == MediaType.IMAGE) {
                            "لا توجد صور محفوظة في مجلد Halati"
                        } else {
                            "لا توجد فيديوهات محفوظة في مجلد Halati"
                        },
                        description = "احفظ أي حالة من تبويب واتساب أو واتساب الأعمال وسيتم تخزينها تلقائياً داخل Pictures/Halati وMovies/Halati."
                    )
                } else {
                    LazyVerticalGrid(
                        columns = GridCells.Adaptive(minSize = 152.dp),
                        contentPadding = PaddingValues(bottom = if (selectionMode) 84.dp else 16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        items(visibleItems, key = { it.id }) { item ->
                            StatusThumbnailGridCard(
                                uri = item.uri,
                                mediaType = item.mediaType,
                                sizeBytes = item.sizeBytes,
                                durationMillis = item.durationMillis,
                                isSaved = false,
                                isSelected = item.id in selectedIds,
                                selectionMode = selectionMode,
                                onClick = {
                                    if (selectionMode) {
                                        onItemLongClick(item)
                                    } else {
                                        onItemClick(item)
                                    }
                                },
                                onLongClick = { onItemLongClick(item) }
                            )
                        }
                    }
                }
            }
        }

        if (selectionMode) {
            val targets = savedItems.filter { it.id in selectedIds }
            Surface(
                color = HalatiColors.SurfaceElevated,
                shape = RoundedCornerShape(18.dp),
                border = BorderStroke(1.dp, HalatiColors.DangerRed.copy(alpha = 0.5f)),
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = onClearSelection) {
                            Icon(
                                imageVector = Icons.Rounded.Close,
                                contentDescription = "إلغاء التحديد",
                                tint = HalatiColors.TextSecondary
                            )
                        }
                        Text(
                            text = "تم تحديد ${targets.size}",
                            style = MaterialTheme.typography.titleMedium
                        )
                    }

                    Button(
                        onClick = { onDeleteSelected(targets) },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = HalatiColors.DangerRed,
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Delete,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(text = "حذف المحدد", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
