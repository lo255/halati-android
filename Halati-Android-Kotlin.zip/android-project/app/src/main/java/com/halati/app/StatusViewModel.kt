package com.halati.app

import android.app.Application
import android.content.Intent
import android.content.IntentSender
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

sealed class UiEvent {
    data class LaunchIntent(val intent: Intent) : UiEvent()
    data class LaunchDeleteConfirmation(val intentSender: IntentSender) : UiEvent()
}

class StatusViewModel(application: Application) : AndroidViewModel(application) {

    val permissionManager = PermissionManager(application)
    val storageManager = StorageManager(application, permissionManager)
    private val statusScanner = StatusScanner(application, storageManager)
    private val mediaRepository = MediaRepository(application)
    private val repository = StatusRepository(
        whatsAppSource = WhatsAppSource(permissionManager, statusScanner),
        businessWhatsAppSource = BusinessWhatsAppSource(permissionManager, statusScanner),
        storageManager = storageManager,
        mediaRepository = mediaRepository
    )

    private val _uiState = MutableStateFlow(
        HalatiUiState(
            autoRefreshOnLaunch = repository.isAutoRefreshEnabled(),
            hasMediaGalleryPermission = permissionManager.hasMediaGalleryPermission(),
            hasAllFilesAccess = permissionManager.hasAllFilesAccess()
        )
    )
    val uiState: StateFlow<HalatiUiState> = _uiState.asStateFlow()

    private val _events = MutableSharedFlow<UiEvent>()
    val events: SharedFlow<UiEvent> = _events.asSharedFlow()

    init {
        if (repository.isAutoRefreshEnabled()) {
            refreshAll()
        }
    }

    fun syncPermissionStateAndRefresh() {
        _uiState.update {
            it.copy(
                hasMediaGalleryPermission = permissionManager.hasMediaGalleryPermission(),
                hasAllFilesAccess = permissionManager.hasAllFilesAccess()
            )
        }
        refreshAll()
    }

    fun refreshAll() {
        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isScanning = true,
                    errorMessage = null,
                    hasMediaGalleryPermission = permissionManager.hasMediaGalleryPermission(),
                    hasAllFilesAccess = permissionManager.hasAllFilesAccess()
                )
            }
            try {
                val snapshot = repository.refreshAll()
                _uiState.update {
                    it.copy(
                        isScanning = false,
                        whatsappResult = snapshot.whatsappResult,
                        businessResult = snapshot.businessResult,
                        savedItems = snapshot.savedItems,
                        lastUpdatedMillis = System.currentTimeMillis()
                    )
                }
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(
                        isScanning = false,
                        errorMessage = e.localizedMessage ?: "حدث خطأ غير متوقع أثناء فحص الحالات."
                    )
                }
            }
        }
    }

    fun onSafTreeGranted(source: StatusSourceType, treeUri: Uri) {
        repository.persistSafFolderPermission(source, treeUri)
        _uiState.update {
            it.copy(bannerMessage = "تم حفظ صلاحية الوصول لمجلد ${source.displayNameAr} بشكل دائم.")
        }
        refreshAll()
    }

    fun revokeSafTree(source: StatusSourceType) {
        repository.revokeSafFolderPermission(source)
        _uiState.update {
            it.copy(bannerMessage = "تم إلغاء ربط مجلد ${source.displayNameAr}.")
        }
        refreshAll()
    }

    fun setAutoRefreshOnLaunch(enabled: Boolean) {
        repository.setAutoRefreshEnabled(enabled)
        _uiState.update { it.copy(autoRefreshOnLaunch = enabled) }
    }

    fun setFilter(source: StatusSourceType, mediaType: MediaType) {
        _uiState.update { state ->
            when (source) {
                StatusSourceType.WHATSAPP -> state.copy(activeFilterWhatsApp = mediaType)
                StatusSourceType.WHATSAPP_BUSINESS -> state.copy(activeFilterBusiness = mediaType)
            }
        }
    }

    fun setSavedFilter(mediaType: MediaType) {
        _uiState.update { it.copy(activeFilterSaved = mediaType) }
    }

    fun toggleStatusSelection(statusId: String) {
        _uiState.update { state ->
            val next = state.selectedStatusIds.toMutableSet()
            if (!next.add(statusId)) next.remove(statusId)
            state.copy(selectedStatusIds = next)
        }
    }

    fun clearStatusSelection() {
        _uiState.update { it.copy(selectedStatusIds = emptySet()) }
    }

    fun toggleSavedSelection(savedId: Long) {
        _uiState.update { state ->
            val next = state.selectedSavedIds.toMutableSet()
            if (!next.add(savedId)) next.remove(savedId)
            state.copy(selectedSavedIds = next)
        }
    }

    fun clearSavedSelection() {
        _uiState.update { it.copy(selectedSavedIds = emptySet()) }
    }

    fun saveSingleStatus(item: StatusItem) {
        viewModelScope.launch {
            _uiState.update { it.copy(isSaving = true) }
            val outcome = repository.saveSingle(item)
            val message = when (outcome) {
                SaveSingleOutcome.SAVED -> "تم حفظ الحالة في مجلد Halati داخل المعرض."
                SaveSingleOutcome.DUPLICATE -> "هذه الحالة محفوظة مسبقاً دون تكرار."
                SaveSingleOutcome.FAILED -> "تعذّر حفظ الملف. تحقق من مساحة التخزين وصلاحية المعرض."
            }
            _uiState.update { it.copy(isSaving = false, bannerMessage = message) }
            refreshAll()
        }
    }

    fun saveSelectedStatuses(allVisibleItems: List<StatusItem>) {
        val selectedIds = _uiState.value.selectedStatusIds
        val targets = allVisibleItems.filter { it.id in selectedIds }
        if (targets.isEmpty()) return

        viewModelScope.launch {
            _uiState.update { it.copy(isSaving = true) }
            val result = repository.saveMultiple(targets)
            val message = buildString {
                append("تم حفظ ${result.savedCount} ملفات")
                if (result.duplicateCount > 0) {
                    append(" • تم تجاهل ${result.duplicateCount} مكررة")
                }
                if (result.failedCount > 0) {
                    append(" • فشل ${result.failedCount}")
                }
            }
            _uiState.update {
                it.copy(
                    isSaving = false,
                    selectedStatusIds = emptySet(),
                    bannerMessage = message
                )
            }
            refreshAll()
        }
    }

    fun deleteSavedItems(targets: List<SavedMediaItem>) {
        if (targets.isEmpty()) return
        viewModelScope.launch {
            when (val outcome = repository.deleteSaved(targets)) {
                is DeleteOutcome.Deleted -> {
                    _uiState.update {
                        it.copy(
                            selectedSavedIds = emptySet(),
                            bannerMessage = "تم حذف ${targets.size} من المحفوظات."
                        )
                    }
                    refreshAll()
                }
                is DeleteOutcome.RequiresConfirmation -> {
                    _events.emit(UiEvent.LaunchDeleteConfirmation(outcome.intentSender))
                }
                is DeleteOutcome.Failed -> {
                    _uiState.update { it.copy(errorMessage = outcome.message) }
                }
            }
        }
    }

    fun shareMedia(uri: Uri, fileName: String, mimeType: String, targetPackage: String? = null) {
        viewModelScope.launch {
            if (targetPackage != null && !permissionManager.isPackageInstalled(targetPackage)) {
                _uiState.update {
                    it.copy(bannerMessage = "التطبيق المطلوب لإعادة النشر غير مثبت على هذا الجهاز.")
                }
                return@launch
            }
            val intent = repository.buildShareIntent(uri, fileName, mimeType, targetPackage)
            if (intent == null) {
                _uiState.update { it.copy(errorMessage = "تعذّر تجهيز الملف للمشاركة.") }
            } else {
                _events.emit(UiEvent.LaunchIntent(intent))
            }
        }
    }

    fun notifyPermissionDenied(explanation: String) {
        _uiState.update { it.copy(errorMessage = explanation) }
    }

    fun clearBanner() {
        _uiState.update { it.copy(bannerMessage = null) }
    }

    fun clearError() {
        _uiState.update { it.copy(errorMessage = null) }
    }
}
