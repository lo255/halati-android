package com.halati.app

class WhatsAppSource(
    private val permissionManager: PermissionManager,
    private val statusScanner: StatusScanner
) {
    val sourceType: StatusSourceType = StatusSourceType.WHATSAPP

    fun isInstalled(): Boolean {
        return permissionManager.isPackageInstalled(sourceType.packageName)
    }

    suspend fun scanStatuses(): SourceScanResult {
        return statusScanner.scanSource(
            source = sourceType,
            isAppInstalled = isInstalled()
        )
    }
}
