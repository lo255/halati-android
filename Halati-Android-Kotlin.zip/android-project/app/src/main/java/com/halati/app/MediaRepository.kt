package com.halati.app

import android.app.RecoverableSecurityException
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.IntentSender
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.FileProvider
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.InputStream
import java.security.MessageDigest

sealed class DeleteOutcome {
    data object Deleted : DeleteOutcome()
    data class RequiresConfirmation(val intentSender: IntentSender) : DeleteOutcome()
    data class Failed(val message: String) : DeleteOutcome()
}

enum class SaveSingleOutcome {
    SAVED,
    DUPLICATE,
    FAILED
}

class MediaRepository(
    private val context: Context,
    private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO
) {
    private val prefs = context.getSharedPreferences(PREFS_SAVED_INDEX, Context.MODE_PRIVATE)

    suspend fun saveStatus(item: StatusItem): SaveSingleOutcome = withContext(ioDispatcher) {
        val digest = computeSha256(item.uri) ?: return@withContext SaveSingleOutcome.FAILED
        if (isAlreadySaved(item.fileName, item.sizeBytes, digest)) {
            return@withContext SaveSingleOutcome.DUPLICATE
        }

        val collectionUri = if (item.mediaType == MediaType.IMAGE) {
            MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        } else {
            MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        }

        val relativeFolder = if (item.mediaType == MediaType.IMAGE) {
            "${Environment.DIRECTORY_PICTURES}/$HALATI_FOLDER_NAME"
        } else {
            "${Environment.DIRECTORY_MOVIES}/$HALATI_FOLDER_NAME"
        }

        val targetDisplayName = buildHalatiDisplayName(item.source, item.fileName)
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, targetDisplayName)
            put(MediaStore.MediaColumns.MIME_TYPE, item.mimeType)
            put(MediaStore.MediaColumns.RELATIVE_PATH, relativeFolder)
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }

        val resolver = context.contentResolver
        val insertedUri = resolver.insert(collectionUri, values)
            ?: return@withContext SaveSingleOutcome.FAILED

        try {
            val copied = resolver.openInputStream(item.uri)?.use { input ->
                resolver.openOutputStream(insertedUri)?.use { output ->
                    input.copyTo(output, bufferSize = DEFAULT_BUFFER_SIZE)
                    true
                } ?: false
            } ?: false

            if (!copied) {
                resolver.delete(insertedUri, null, null)
                return@withContext SaveSingleOutcome.FAILED
            }

            val publishValues = ContentValues().apply {
                put(MediaStore.MediaColumns.IS_PENDING, 0)
            }
            resolver.update(insertedUri, publishValues, null, null)
            recordSavedFingerprint(digest, targetDisplayName, item.fileName)
            SaveSingleOutcome.SAVED
        } catch (_: Exception) {
            runCatching { resolver.delete(insertedUri, null, null) }
            SaveSingleOutcome.FAILED
        }
    }

    suspend fun saveBatch(items: List<StatusItem>): BatchSaveResult = withContext(ioDispatcher) {
        var saved = 0
        var duplicates = 0
        var failed = 0
        for (item in items) {
            when (saveStatus(item)) {
                SaveSingleOutcome.SAVED -> saved++
                SaveSingleOutcome.DUPLICATE -> duplicates++
                SaveSingleOutcome.FAILED -> failed++
            }
        }
        BatchSaveResult(savedCount = saved, duplicateCount = duplicates, failedCount = failed)
    }

    suspend fun loadSavedMedia(): List<SavedMediaItem> = withContext(ioDispatcher) {
        val images = querySavedCollection(
            collectionUri = MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY),
            mediaType = MediaType.IMAGE,
            folderFilter = "%$HALATI_FOLDER_NAME%"
        )
        val videos = querySavedCollection(
            collectionUri = MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY),
            mediaType = MediaType.VIDEO,
            folderFilter = "%$HALATI_FOLDER_NAME%"
        )
        (images + videos).sortedByDescending { it.dateAddedMillis }
    }

    suspend fun isStatusSavedInGallery(item: StatusItem): Boolean = withContext(ioDispatcher) {
        val existingHashes = getRecordedHashes()
        val expectedName = buildHalatiDisplayName(item.source, item.fileName)
        if (prefs.getStringSet(KEY_SAVED_NAMES, emptySet())?.contains(expectedName) == true) {
            return@withContext true
        }
        if (existingHashes.isEmpty()) return@withContext false
        val digest = computeSha256(item.uri) ?: return@withContext false
        digest in existingHashes
    }

    suspend fun getSavedFileNamesIndex(): Set<String> = withContext(ioDispatcher) {
        val savedNames = loadSavedMedia().map { it.displayName }.toMutableSet()
        savedNames.addAll(prefs.getStringSet(KEY_ORIGINAL_NAMES, emptySet()).orEmpty())
        savedNames
    }

    suspend fun deleteSavedItems(items: List<SavedMediaItem>): DeleteOutcome = withContext(ioDispatcher) {
        if (items.isEmpty()) return@withContext DeleteOutcome.Deleted
        val resolver = context.contentResolver

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val directFailures = mutableListOf<SavedMediaItem>()
            for (item in items) {
                val deletedRows = runCatching { resolver.delete(item.uri, null, null) }.getOrDefault(0)
                if (deletedRows <= 0) {
                    directFailures.add(item)
                } else {
                    removeSavedNameRecord(item.displayName)
                }
            }
            if (directFailures.isEmpty()) {
                return@withContext DeleteOutcome.Deleted
            }
            val pendingIntent = MediaStore.createDeleteRequest(
                resolver,
                directFailures.map { it.uri }
            )
            return@withContext DeleteOutcome.RequiresConfirmation(pendingIntent.intentSender)
        }

        // Android 10 (API 29)
        try {
            for (item in items) {
                resolver.delete(item.uri, null, null)
                removeSavedNameRecord(item.displayName)
            }
            DeleteOutcome.Deleted
        } catch (securityException: SecurityException) {
            val recoverable = securityException as? RecoverableSecurityException
            if (recoverable != null) {
                DeleteOutcome.RequiresConfirmation(recoverable.userAction.actionIntent.intentSender)
            } else {
                DeleteOutcome.Failed("لا تتوفر صلاحية حذف هذا الملف من المعرض.")
            }
        } catch (_: Exception) {
            DeleteOutcome.Failed("تعذّر حذف الملفات المحددة.")
        }
    }

    suspend fun createShareIntent(
        uri: Uri,
        fileName: String,
        mimeType: String,
        targetPackage: String? = null
    ): Intent? = withContext(ioDispatcher) {
        val shareUri = resolveShareableUri(uri, fileName) ?: return@withContext null
        val sendIntent = Intent(Intent.ACTION_SEND).apply {
            type = mimeType
            putExtra(Intent.EXTRA_STREAM, shareUri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            if (!targetPackage.isNullOrBlank()) {
                setPackage(targetPackage)
            }
        }
        if (targetPackage == null) {
            Intent.createChooser(sendIntent, "مشاركة الحالة")
        } else {
            sendIntent
        }
    }

    private fun resolveShareableUri(sourceUri: Uri, fileName: String): Uri? {
        if (sourceUri.scheme == "content" && sourceUri.authority == MediaStore.AUTHORITY) {
            return sourceUri
        }
        val shareCacheDir = File(context.cacheDir, "shared_statuses").apply { mkdirs() }
        val safeName = fileName.replace(Regex("[^A-Za-z0-9._-]"), "_")
        val tempFile = File(shareCacheDir, safeName)
        return try {
            context.contentResolver.openInputStream(sourceUri)?.use { input ->
                tempFile.outputStream().use { output ->
                    input.copyTo(output)
                }
            } ?: return null
            FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                tempFile
            )
        } catch (_: Exception) {
            null
        }
    }

    private fun querySavedCollection(
        collectionUri: Uri,
        mediaType: MediaType,
        folderFilter: String
    ): List<SavedMediaItem> {
        val result = mutableListOf<SavedMediaItem>()
        val projection = buildList {
            add(MediaStore.MediaColumns._ID)
            add(MediaStore.MediaColumns.DISPLAY_NAME)
            add(MediaStore.MediaColumns.MIME_TYPE)
            add(MediaStore.MediaColumns.SIZE)
            add(MediaStore.MediaColumns.DATE_ADDED)
            add(MediaStore.MediaColumns.RELATIVE_PATH)
            if (mediaType == MediaType.VIDEO) {
                add(MediaStore.Video.VideoColumns.DURATION)
            }
        }.toTypedArray()

        val selection = "${MediaStore.MediaColumns.RELATIVE_PATH} LIKE ?"
        val selectionArgs = arrayOf(folderFilter)
        val sortOrder = "${MediaStore.MediaColumns.DATE_ADDED} DESC"

        runCatching {
            context.contentResolver.query(
                collectionUri,
                projection,
                selection,
                selectionArgs,
                sortOrder
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
                val nameCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
                val mimeCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.MIME_TYPE)
                val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE)
                val dateCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_ADDED)
                val pathCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.RELATIVE_PATH)
                val durationCol = if (mediaType == MediaType.VIDEO) {
                    cursor.getColumnIndex(MediaStore.Video.VideoColumns.DURATION)
                } else {
                    -1
                }

                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idCol)
                    val displayName = cursor.getString(nameCol) ?: continue
                    val mime = cursor.getString(mimeCol) ?: if (mediaType == MediaType.IMAGE) "image/jpeg" else "video/mp4"
                    val size = cursor.getLong(sizeCol)
                    val dateSec = cursor.getLong(dateCol)
                    val relPath = cursor.getString(pathCol) ?: ""
                    val duration = if (durationCol >= 0) cursor.getLong(durationCol) else 0L
                    val itemUri = ContentUris.withAppendedId(collectionUri, id)

                    result.add(
                        SavedMediaItem(
                            id = id,
                            uri = itemUri,
                            displayName = displayName,
                            mimeType = mime,
                            mediaType = mediaType,
                            sizeBytes = size,
                            dateAddedMillis = dateSec * 1000L,
                            durationMillis = duration,
                            relativePath = relPath
                        )
                    )
                }
            }
        }
        return result
    }

    private fun isAlreadySaved(
        originalFileName: String,
        sizeBytes: Long,
        sha256: String
    ): Boolean {
        if (sha256 in getRecordedHashes()) return true
        val savedList = queryMediaStoreByNameAndSize(originalFileName, sizeBytes)
        return savedList
    }

    private fun queryMediaStoreByNameAndSize(originalFileName: String, sizeBytes: Long): Boolean {
        val candidateNames = setOf(
            originalFileName,
            buildHalatiDisplayName(StatusSourceType.WHATSAPP, originalFileName),
            buildHalatiDisplayName(StatusSourceType.WHATSAPP_BUSINESS, originalFileName)
        )
        val collections = listOf(
            MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY),
            MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        )
        for (collection in collections) {
            val found = runCatching {
                context.contentResolver.query(
                    collection,
                    arrayOf(MediaStore.MediaColumns.DISPLAY_NAME, MediaStore.MediaColumns.SIZE),
                    "${MediaStore.MediaColumns.RELATIVE_PATH} LIKE ?",
                    arrayOf("%$HALATI_FOLDER_NAME%"),
                    null
                )?.use { cursor ->
                    val nameIdx = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
                    val sizeIdx = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE)
                    while (cursor.moveToNext()) {
                        val name = cursor.getString(nameIdx)
                        val size = cursor.getLong(sizeIdx)
                        if (name in candidateNames && size == sizeBytes) {
                            return@use true
                        }
                    }
                    false
                } ?: false
            }.getOrDefault(false)
            if (found) return true
        }
        return false
    }

    internal fun computeSha256(uri: Uri): String? {
        return runCatching {
            context.contentResolver.openInputStream(uri)?.use { stream ->
                sha256FromStream(stream)
            }
        }.getOrNull()
    }

    private fun getRecordedHashes(): Set<String> {
        return prefs.getStringSet(KEY_SAVED_HASHES, emptySet()).orEmpty()
    }

    private fun recordSavedFingerprint(hash: String, savedDisplayName: String, originalName: String) {
        val hashes = getRecordedHashes().toMutableSet().apply { add(hash) }
        val names = prefs.getStringSet(KEY_SAVED_NAMES, emptySet()).orEmpty().toMutableSet().apply {
            add(savedDisplayName)
        }
        val originals = prefs.getStringSet(KEY_ORIGINAL_NAMES, emptySet()).orEmpty().toMutableSet().apply {
            add(originalName)
        }
        prefs.edit()
            .putStringSet(KEY_SAVED_HASHES, hashes)
            .putStringSet(KEY_SAVED_NAMES, names)
            .putStringSet(KEY_ORIGINAL_NAMES, originals)
            .apply()
    }

    private fun removeSavedNameRecord(savedDisplayName: String) {
        val names = prefs.getStringSet(KEY_SAVED_NAMES, emptySet()).orEmpty().toMutableSet()
        names.remove(savedDisplayName)
        prefs.edit().putStringSet(KEY_SAVED_NAMES, names).apply()
    }

    companion object {
        const val HALATI_FOLDER_NAME = "Halati"
        private const val PREFS_SAVED_INDEX = "halati_saved_index"
        private const val KEY_SAVED_HASHES = "saved_sha256_hashes"
        private const val KEY_SAVED_NAMES = "saved_display_names"
        private const val KEY_ORIGINAL_NAMES = "saved_original_names"

        fun buildHalatiDisplayName(source: StatusSourceType, originalFileName: String): String {
            val prefix = when (source) {
                StatusSourceType.WHATSAPP -> "WA"
                StatusSourceType.WHATSAPP_BUSINESS -> "WAB"
            }
            return "Halati_${prefix}_$originalFileName"
        }

        fun sha256FromStream(input: InputStream): String {
            val digest = MessageDigest.getInstance("SHA-256")
            val buffer = ByteArray(8192)
            var bytesRead = input.read(buffer)
            while (bytesRead != -1) {
                digest.update(buffer, 0, bytesRead)
                bytesRead = input.read(buffer)
            }
            return digest.digest().joinToString("") { "%02x".format(it) }
        }
    }
}
