package com.halati.app

import android.net.Uri

enum class StatusSourceType(
    val displayNameAr: String,
    val packageName: String,
    val scopedRelativePath: String,
    val legacyRelativePath: String,
    val safInitialDocumentId: String
) {
    WHATSAPP(
        displayNameAr = "واتساب",
        packageName = "com.whatsapp",
        scopedRelativePath = "Android/media/com.whatsapp/WhatsApp/Media/.Statuses",
        legacyRelativePath = "WhatsApp/Media/.Statuses",
        safInitialDocumentId = "primary:Android/media/com.whatsapp/WhatsApp/Media/.Statuses"
    ),
    WHATSAPP_BUSINESS(
        displayNameAr = "واتساب الأعمال",
        packageName = "com.whatsapp.w4b",
        scopedRelativePath = "Android/media/com.whatsapp.w4b/WhatsApp Business/Media/.Statuses",
        legacyRelativePath = "WhatsApp Business/Media/.Statuses",
        safInitialDocumentId = "primary:Android/media/com.whatsapp.w4b/WhatsApp Business/Media/.Statuses"
    )
}

enum class MediaType(val labelAr: String) {
    IMAGE("الصور"),
    VIDEO("الفيديوهات")
}

enum class AccessMode(val labelAr: String) {
    SAF_PERSISTED("وصول محمي دائم (SAF)"),
    DIRECT_ALL_FILES("وصول مباشر للملفات (All Files)"),
    LEGACY_STORAGE("تخزين Android 10 التوافقي"),
    NONE("يتطلب منح الإذن")
}

enum class SourceAccessState {
    READY,
    NEEDS_FOLDER_PERMISSION,
    FOLDER_NOT_FOUND_OR_EMPTY,
    APP_NOT_INSTALLED
}

data class StatusItem(
    val id: String,
    val uri: Uri,
    val fileName: String,
    val mimeType: String,
    val mediaType: MediaType,
    val source: StatusSourceType,
    val sizeBytes: Long,
    val lastModifiedMillis: Long,
    val durationMillis: Long = 0L,
    val isSaved: Boolean = false
)

data class SavedMediaItem(
    val id: Long,
    val uri: Uri,
    val displayName: String,
    val mimeType: String,
    val mediaType: MediaType,
    val sizeBytes: Long,
    val dateAddedMillis: Long,
    val durationMillis: Long = 0L,
    val relativePath: String = ""
)

data class SourceScanResult(
    val source: StatusSourceType,
    val accessState: SourceAccessState,
    val accessMode: AccessMode,
    val items: List<StatusItem> = emptyList(),
    val resolvedPathLabel: String? = null,
    val errorMessage: String? = null
)

data class BatchSaveResult(
    val savedCount: Int,
    val duplicateCount: Int,
    val failedCount: Int
)

enum class HalatiTab(val route: String, val labelAr: String) {
    HOME("home", "الرئيسية"),
    WHATSAPP("whatsapp", "واتساب"),
    BUSINESS("business", "واتساب الأعمال"),
    SAVED("saved", "المحفوظات"),
    SETTINGS("settings", "الإعدادات")
}

data class HalatiUiState(
    val isScanning: Boolean = false,
    val isSaving: Boolean = false,
    val autoRefreshOnLaunch: Boolean = true,
    val whatsappResult: SourceScanResult = SourceScanResult(
        source = StatusSourceType.WHATSAPP,
        accessState = SourceAccessState.NEEDS_FOLDER_PERMISSION,
        accessMode = AccessMode.NONE
    ),
    val businessResult: SourceScanResult = SourceScanResult(
        source = StatusSourceType.WHATSAPP_BUSINESS,
        accessState = SourceAccessState.NEEDS_FOLDER_PERMISSION,
        accessMode = AccessMode.NONE
    ),
    val savedItems: List<SavedMediaItem> = emptyList(),
    val selectedStatusIds: Set<String> = emptySet(),
    val selectedSavedIds: Set<Long> = emptySet(),
    val activeFilterWhatsApp: MediaType = MediaType.IMAGE,
    val activeFilterBusiness: MediaType = MediaType.IMAGE,
    val activeFilterSaved: MediaType = MediaType.IMAGE,
    val hasMediaGalleryPermission: Boolean = false,
    val hasAllFilesAccess: Boolean = false,
    val bannerMessage: String? = null,
    val errorMessage: String? = null,
    val lastUpdatedMillis: Long = 0L
)
