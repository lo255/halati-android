package com.halati.app

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.BusinessCenter
import androidx.compose.material.icons.rounded.Chat
import androidx.compose.material.icons.rounded.CollectionsBookmark
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@Composable
fun HomeScreen(
    uiState: HalatiUiState,
    onNavigateTab: (HalatiTab) -> Unit,
    onRequestSafFolder: (StatusSourceType) -> Unit,
    onOpenStatusViewer: (StatusItem) -> Unit,
    onQuickSaveStatus: (StatusItem) -> Unit,
    onDismissError: () -> Unit
) {
    val allRecentStatuses = (uiState.whatsappResult.items + uiState.businessResult.items)
        .sortedByDescending { it.lastModifiedMillis }
        .take(12)

    val waImages = uiState.whatsappResult.items.count { it.mediaType == MediaType.IMAGE }
    val waVideos = uiState.whatsappResult.items.count { it.mediaType == MediaType.VIDEO }
    val bizImages = uiState.businessResult.items.count { it.mediaType == MediaType.IMAGE }
    val bizVideos = uiState.businessResult.items.count { it.mediaType == MediaType.VIDEO }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(HalatiColors.PitchBlack),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        if (!uiState.errorMessage.isNullOrBlank()) {
            item {
                ErrorBanner(
                    message = uiState.errorMessage,
                    onDismiss = onDismissError
                )
            }
        }

        // Source Overview Cards
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                SourceOverviewCard(
                    title = "واتساب",
                    subtitle = "$waImages صور • $waVideos فيديو",
                    scanResult = uiState.whatsappResult,
                    accentColor = HalatiColors.EmeraldPrimary,
                    icon = Icons.Rounded.Chat,
                    onClick = { onNavigateTab(HalatiTab.WHATSAPP) },
                    onGrantClick = { onRequestSafFolder(StatusSourceType.WHATSAPP) },
                    modifier = Modifier.weight(1f)
                )
                SourceOverviewCard(
                    title = "واتساب الأعمال",
                    subtitle = "$bizImages صور • $bizVideos فيديو",
                    scanResult = uiState.businessResult,
                    accentColor = HalatiColors.GoldAccent,
                    icon = Icons.Rounded.BusinessCenter,
                    onClick = { onNavigateTab(HalatiTab.BUSINESS) },
                    onGrantClick = { onRequestSafFolder(StatusSourceType.WHATSAPP_BUSINESS) },
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Saved Summary Card
        item {
            Surface(
                color = HalatiColors.SurfaceDark,
                shape = RoundedCornerShape(18.dp),
                border = BorderStroke(1.dp, HalatiColors.HairlineBorder),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onNavigateTab(HalatiTab.SAVED) }
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(HalatiColors.EmeraldDeep.copy(alpha = 0.45f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.CollectionsBookmark,
                                contentDescription = null,
                                tint = HalatiColors.EmeraldPrimary
                            )
                        }
                        Column {
                            Text(
                                text = "مجلد المحفوظات (Halati)",
                                style = MaterialTheme.typography.titleMedium
                            )
                            Text(
                                text = "${uiState.savedItems.size} ملفاً محفوظاً في معرض الهاتف",
                                style = MaterialTheme.typography.labelMedium,
                                color = HalatiColors.TextSecondary
                            )
                        }
                    }
                    Text(
                        text = "عرض الكل",
                        style = MaterialTheme.typography.labelMedium,
                        color = HalatiColors.EmeraldPrimary,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Recent Statuses Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "أحدث الحالات المكتشفة",
                    style = MaterialTheme.typography.titleLarge
                )
                Text(
                    text = "${allRecentStatuses.size} حالة",
                    style = MaterialTheme.typography.labelMedium,
                    color = HalatiColors.TextSecondary
                )
            }
        }

        if (allRecentStatuses.isEmpty()) {
            item {
                EmptyStatusState(
                    title = "لا توجد حالات ظاهرة حالياً",
                    description = "افتح تطبيق واتساب وشاهد الحالات أولاً حتى تُخزّن مؤقتاً على الجهاز، ثم امنح التطبيق إذن مجلد .Statuses من تبويب واتساب أو واتساب الأعمال.",
                    actionLabel = "فتح تبويب واتساب",
                    onActionClick = { onNavigateTab(HalatiTab.WHATSAPP) }
                )
            }
        } else {
            item {
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(allRecentStatuses, key = { it.id }) { status ->
                        Box(modifier = Modifier.width(156.dp)) {
                            StatusThumbnailGridCard(
                                uri = status.uri,
                                mediaType = status.mediaType,
                                sizeBytes = status.sizeBytes,
                                durationMillis = status.durationMillis,
                                isSaved = status.isSaved,
                                isSelected = false,
                                selectionMode = false,
                                onClick = { onOpenStatusViewer(status) },
                                onLongClick = { onOpenStatusViewer(status) },
                                onQuickActionClick = { onQuickSaveStatus(status) }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SourceOverviewCard(
    title: String,
    subtitle: String,
    scanResult: SourceScanResult,
    accentColor: Color,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit,
    onGrantClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = HalatiColors.SurfaceDark,
        shape = RoundedCornerShape(18.dp),
        border = BorderStroke(1.dp, HalatiColors.HairlineBorder),
        modifier = modifier.clickable(onClick = onClick)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = accentColor,
                    modifier = Modifier.size(20.dp)
                )
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    maxLines = 1
                )
            }

            val statusLabel = when (scanResult.accessState) {
                SourceAccessState.READY -> subtitle
                SourceAccessState.NEEDS_FOLDER_PERMISSION -> "بانتظار إذن المجلد"
                SourceAccessState.FOLDER_NOT_FOUND_OR_EMPTY -> "المجلد فارغ حالياً"
                SourceAccessState.APP_NOT_INSTALLED -> "غير مثبت على الجهاز"
            }

            Text(
                text = statusLabel,
                style = MaterialTheme.typography.bodyMedium,
                color = if (scanResult.accessState == SourceAccessState.READY) {
                    HalatiColors.TextPrimary
                } else {
                    HalatiColors.TextSecondary
                }
            )

            if (scanResult.accessState == SourceAccessState.NEEDS_FOLDER_PERMISSION) {
                Surface(
                    onClick = onGrantClick,
                    color = accentColor.copy(alpha = 0.14f),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 10.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.FolderOpen,
                            contentDescription = null,
                            tint = accentColor,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "تحديد المجلد",
                            style = MaterialTheme.typography.labelMedium,
                            color = accentColor,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            } else {
                Text(
                    text = scanResult.accessMode.labelAr,
                    style = MaterialTheme.typography.labelSmall,
                    color = HalatiColors.TextMuted
                )
            }
        }
    }
}
