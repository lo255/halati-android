package com.halati.app

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@Composable
fun StatusesScreen(
    source: StatusSourceType,
    scanResult: SourceScanResult,
    selectedMediaType: MediaType,
    selectedIds: Set<String>,
    isScanning: Boolean,
    isSaving: Boolean,
    onSelectMediaType: (MediaType) -> Unit,
    onGrantSafClick: () -> Unit,
    onOpenAllFilesSettings: () -> Unit,
    onRefreshClick: () -> Unit,
    onItemClick: (StatusItem) -> Unit,
    onItemLongClick: (StatusItem) -> Unit,
    onQuickSave: (StatusItem) -> Unit,
    onSaveSelected: (List<StatusItem>) -> Unit,
    onClearSelection: () -> Unit
) {
    val images = scanResult.items.filter { it.mediaType == MediaType.IMAGE }
    val videos = scanResult.items.filter { it.mediaType == MediaType.VIDEO }
    val visibleItems = if (selectedMediaType == MediaType.IMAGE) images else videos
    val selectionMode = selectedIds.isNotEmpty()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(HalatiColors.PitchBlack)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (scanResult.accessState == SourceAccessState.NEEDS_FOLDER_PERMISSION) {
                PermissionGuideCard(
                    source = source,
                    onGrantSafClick = onGrantSafClick,
                    onOpenAllFilesSettings = onOpenAllFilesSettings
                )
            } else if (scanResult.accessState == SourceAccessState.APP_NOT_INSTALLED) {
                EmptyStatusState(
                    title = "تطبيق ${source.displayNameAr} غير مثبت",
                    description = "لم يتم العثور على الحزمة (${source.packageName}) على هذا الجهاز. إذا كانت الحالات مخزنة يدوياً في المجلد، يمكنك منح إذن المجلد يدوياً.",
                    actionLabel = "تحديد المجلد يدوياً",
                    onActionClick = onGrantSafClick
                )
            } else {
                MediaTypeSegmentedToggle(
                    selectedType = selectedMediaType,
                    imageCount = images.size,
                    videoCount = videos.size,
                    onSelect = onSelectMediaType
                )

                if (isScanning && scanResult.items.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator(color = HalatiColors.EmeraldPrimary)
                    }
                } else if (visibleItems.isEmpty()) {
                    EmptyStatusState(
                        title = if (selectedMediaType == MediaType.IMAGE) {
                            "لا توجد صور حالات في ${source.displayNameAr}"
                        } else {
                            "لا توجد فيديوهات حالات في ${source.displayNameAr}"
                        },
                        description = "تظهر الحالات هنا تلقائياً بعد مشاهدتها داخل ${source.displayNameAr}. المجلدات الفارغة لا تُعرض كحالات متاحة.",
                        actionLabel = "تحديث الآن",
                        onActionClick = onRefreshClick
                    )
                } else {
                    LazyVerticalGrid(
                        columns = GridCells.Adaptive(minSize = 152.dp),
                        contentPadding = PaddingValues(bottom = if (selectionMode) 84.dp else 16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        items(visibleItems, key = { it.id }) { item ->
                            StatusThumbnailGridCard(
                                uri = item.uri,
                                mediaType = item.mediaType,
                                sizeBytes = item.sizeBytes,
                                durationMillis = item.durationMillis,
                                isSaved = item.isSaved,
                                isSelected = item.id in selectedIds,
                                selectionMode = selectionMode,
                                onClick = {
                                    if (selectionMode) {
                                        onItemLongClick(item)
                                    } else {
                                        onItemClick(item)
                                    }
                                },
                                onLongClick = { onItemLongClick(item) },
                                onQuickActionClick = { onQuickSave(item) }
                            )
                        }
                    }
                }
            }
        }

        if (selectionMode) {
            Surface(
                color = HalatiColors.SurfaceElevated,
                shape = RoundedCornerShape(18.dp),
                border = BorderStroke(1.dp, HalatiColors.EmeraldPrimary.copy(alpha = 0.45f)),
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = onClearSelection) {
                            Icon(
                                imageVector = Icons.Rounded.Close,
                                contentDescription = "إلغاء التحديد",
                                tint = HalatiColors.TextSecondary
                            )
                        }
                        Text(
                            text = "تم تحديد ${selectedIds.size}",
                            style = MaterialTheme.typography.titleMedium
                        )
                    }

                    Button(
                        onClick = { onSaveSelected(scanResult.items) },
                        enabled = !isSaving,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = HalatiColors.EmeraldPrimary,
                            contentColor = Color(0xFF031A11)
                        ),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        if (isSaving) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(16.dp),
                                strokeWidth = 2.dp,
                                color = Color(0xFF031A11)
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Rounded.Download,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(text = "حفظ المحدد", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}
