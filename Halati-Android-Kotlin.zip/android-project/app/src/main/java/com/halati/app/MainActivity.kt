package com.halati.app

import android.app.Activity
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.BusinessCenter
import androidx.compose.material.icons.rounded.Chat
import androidx.compose.material.icons.rounded.CollectionsBookmark
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle

class MainActivity : ComponentActivity() {

    private val viewModel: StatusViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(HalatiColors.PitchBlack.toArgb()),
            navigationBarStyle = SystemBarStyle.dark(HalatiColors.SurfaceDark.toArgb())
        )
        setContent {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                HalatiTheme {
                    HalatiRootApp(viewModel = viewModel)
                }
            }
        }
    }
}

@Composable
private fun HalatiRootApp(viewModel: StatusViewModel) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }
    val lifecycleOwner = LocalLifecycleOwner.current

    var currentTab by rememberSaveable { mutableStateOf(HalatiTab.HOME) }
    var pendingSafSource by rememberSaveable { mutableStateOf<StatusSourceType?>(null) }
    var activeViewer by remember { mutableStateOf<ViewerPayload?>(null) }

    val safTreeLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val source = pendingSafSource
        val uri = result.data?.data
        if (result.resultCode == Activity.RESULT_OK && uri != null && source != null) {
            viewModel.onSafTreeGranted(source, uri)
        } else if (source != null) {
            viewModel.notifyPermissionDenied(
                "لم يتم منح صلاحية مجلد ${source.displayNameAr}. يمكنك المحاولة مجدداً واختيار «استخدام هذا المجلد»."
            )
        }
        pendingSafSource = null
    }

    val galleryPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        val grantedAny = results.values.any { it }
        if (!grantedAny) {
            viewModel.notifyPermissionDenied(
                "تم رفض إذن الوصول للصور والفيديوهات. فعّله من إعدادات التطبيق لعرض مجلد المحفوظات."
            )
        }
        viewModel.syncPermissionStateAndRefresh()
    }

    val systemSettingsLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) {
        viewModel.syncPermissionStateAndRefresh()
    }

    val deleteConfirmationLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartIntentSenderForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            viewModel.clearSavedSelection()
            viewModel.refreshAll()
        }
    }

    LaunchedEffect(Unit) {
        viewModel.events.collect { event ->
            when (event) {
                is UiEvent.LaunchIntent -> systemSettingsLauncher.launch(event.intent)
                is UiEvent.LaunchDeleteConfirmation -> {
                    deleteConfirmationLauncher.launch(
                        IntentSenderRequest.Builder(event.intentSender).build()
                    )
                }
            }
        }
    }

    LaunchedEffect(uiState.bannerMessage) {
        val message = uiState.bannerMessage ?: return@LaunchedEffect
        snackbarHostState.showSnackbar(message)
        viewModel.clearBanner()
    }

    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME && uiState.autoRefreshOnLaunch) {
                viewModel.syncPermissionStateAndRefresh()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    val launchSafPicker: (StatusSourceType) -> Unit = { source ->
        pendingSafSource = source
        val intent = viewModel.permissionManager.createSafTreeIntent(source)
        safTreeLauncher.launch(intent)
    }

    val launchGalleryPermission: () -> Unit = {
        galleryPermissionLauncher.launch(viewModel.permissionManager.requiredGalleryPermissions())
    }

    val launchAllFilesSettings: () -> Unit = {
        systemSettingsLauncher.launch(viewModel.permissionManager.createAllFilesSettingsIntent())
    }

    val launchAppSettings: () -> Unit = {
        systemSettingsLauncher.launch(viewModel.permissionManager.createAppDetailsSettingsIntent())
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Scaffold(
            containerColor = HalatiColors.PitchBlack,
            snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
            topBar = {
                val subtitle = when (currentTab) {
                    HalatiTab.HOME -> "حافظ حالات واتساب وواتساب الأعمال"
                    HalatiTab.WHATSAPP -> uiState.whatsappResult.accessMode.labelAr
                    HalatiTab.BUSINESS -> uiState.businessResult.accessMode.labelAr
                    HalatiTab.SAVED -> "معرض Pictures & Movies / Halati"
                    HalatiTab.SETTINGS -> viewModel.permissionManager.androidVersionSummary()
                }
                HalatiTopBar(
                    title = if (currentTab == HalatiTab.HOME) "حالتي" else currentTab.labelAr,
                    subtitle = subtitle,
                    isScanning = uiState.isScanning,
                    onRefreshClick = { viewModel.refreshAll() }
                )
            },
            bottomBar = {
                NavigationBar(containerColor = HalatiColors.SurfaceDark) {
                    HalatiTab.entries.forEach { tab ->
                        val icon = when (tab) {
                            HalatiTab.HOME -> Icons.Rounded.Home
                            HalatiTab.WHATSAPP -> Icons.Rounded.Chat
                            HalatiTab.BUSINESS -> Icons.Rounded.BusinessCenter
                            HalatiTab.SAVED -> Icons.Rounded.CollectionsBookmark
                            HalatiTab.SETTINGS -> Icons.Rounded.Settings
                        }
                        NavigationBarItem(
                            selected = currentTab == tab,
                            onClick = { currentTab = tab },
                            icon = { Icon(imageVector = icon, contentDescription = tab.labelAr) },
                            label = {
                                Text(
                                    text = tab.labelAr,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = HalatiColors.EmeraldPrimary,
                                selectedTextColor = HalatiColors.EmeraldPrimary,
                                indicatorColor = HalatiColors.EmeraldDeep.copy(alpha = 0.55f),
                                unselectedIconColor = HalatiColors.TextSecondary,
                                unselectedTextColor = HalatiColors.TextSecondary
                            )
                        )
                    }
                }
            }
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                when (currentTab) {
                    HalatiTab.HOME -> HomeScreen(
                        uiState = uiState,
                        onNavigateTab = { currentTab = it },
                        onRequestSafFolder = launchSafPicker,
                        onOpenStatusViewer = { item ->
                            activeViewer = ViewerPayload(
                                uri = item.uri,
                                title = item.fileName,
                                mimeType = item.mimeType,
                                mediaType = item.mediaType,
                                sizeBytes = item.sizeBytes,
                                durationMillis = item.durationMillis,
                                isSavedItem = false,
                                sourceStatusItem = item
                            )
                        },
                        onQuickSaveStatus = { viewModel.saveSingleStatus(it) },
                        onDismissError = { viewModel.clearError() }
                    )

                    HalatiTab.WHATSAPP -> StatusesScreen(
                        source = StatusSourceType.WHATSAPP,
                        scanResult = uiState.whatsappResult,
                        selectedMediaType = uiState.activeFilterWhatsApp,
                        selectedIds = uiState.selectedStatusIds,
                        isScanning = uiState.isScanning,
                        isSaving = uiState.isSaving,
                        onSelectMediaType = { viewModel.setFilter(StatusSourceType.WHATSAPP, it) },
                        onGrantSafClick = { launchSafPicker(StatusSourceType.WHATSAPP) },
                        onOpenAllFilesSettings = launchAllFilesSettings,
                        onRefreshClick = { viewModel.refreshAll() },
                        onItemClick = { item ->
                            activeViewer = ViewerPayload(
                                uri = item.uri,
                                title = item.fileName,
                                mimeType = item.mimeType,
                                mediaType = item.mediaType,
                                sizeBytes = item.sizeBytes,
                                durationMillis = item.durationMillis,
                                isSavedItem = false,
                                sourceStatusItem = item
                            )
                        },
                        onItemLongClick = { viewModel.toggleStatusSelection(it.id) },
                        onQuickSave = { viewModel.saveSingleStatus(it) },
                        onSaveSelected = { viewModel.saveSelectedStatuses(it) },
                        onClearSelection = { viewModel.clearStatusSelection() }
                    )

                    HalatiTab.BUSINESS -> StatusesScreen(
                        source = StatusSourceType.WHATSAPP_BUSINESS,
                        scanResult = uiState.businessResult,
                        selectedMediaType = uiState.activeFilterBusiness,
                        selectedIds = uiState.selectedStatusIds,
                        isScanning = uiState.isScanning,
                        isSaving = uiState.isSaving,
                        onSelectMediaType = { viewModel.setFilter(StatusSourceType.WHATSAPP_BUSINESS, it) },
                        onGrantSafClick = { launchSafPicker(StatusSourceType.WHATSAPP_BUSINESS) },
                        onOpenAllFilesSettings = launchAllFilesSettings,
                        onRefreshClick = { viewModel.refreshAll() },
                        onItemClick = { item ->
                            activeViewer = ViewerPayload(
                                uri = item.uri,
                                title = item.fileName,
                                mimeType = item.mimeType,
                                mediaType = item.mediaType,
                                sizeBytes = item.sizeBytes,
                                durationMillis = item.durationMillis,
                                isSavedItem = false,
                                sourceStatusItem = item
                            )
                        },
                        onItemLongClick = { viewModel.toggleStatusSelection(it.id) },
                        onQuickSave = { viewModel.saveSingleStatus(it) },
                        onSaveSelected = { viewModel.saveSelectedStatuses(it) },
                        onClearSelection = { viewModel.clearStatusSelection() }
                    )

                    HalatiTab.SAVED -> SavedScreen(
                        savedItems = uiState.savedItems,
                        selectedMediaType = uiState.activeFilterSaved,
                        selectedIds = uiState.selectedSavedIds,
                        hasGalleryPermission = uiState.hasMediaGalleryPermission,
                        onSelectMediaType = { viewModel.setSavedFilter(it) },
                        onRequestGalleryPermission = launchGalleryPermission,
                        onItemClick = { saved ->
                            activeViewer = ViewerPayload(
                                uri = saved.uri,
                                title = saved.displayName,
                                mimeType = saved.mimeType,
                                mediaType = saved.mediaType,
                                sizeBytes = saved.sizeBytes,
                                durationMillis = saved.durationMillis,
                                isSavedItem = true,
                                sourceSavedItem = saved
                            )
                        },
                        onItemLongClick = { viewModel.toggleSavedSelection(it.id) },
                        onDeleteSelected = { viewModel.deleteSavedItems(it) },
                        onClearSelection = { viewModel.clearSavedSelection() }
                    )

                    HalatiTab.SETTINGS -> SettingsScreen(
                        uiState = uiState,
                        androidVersionLabel = viewModel.permissionManager.androidVersionSummary(),
                        onToggleAutoRefresh = { viewModel.setAutoRefreshOnLaunch(it) },
                        onRequestSafFolder = launchSafPicker,
                        onRevokeSafFolder = { viewModel.revokeSafTree(it) },
                        onOpenAllFilesSettings = launchAllFilesSettings,
                        onRequestGalleryPermission = launchGalleryPermission,
                        onOpenAppSettings = launchAppSettings
                    )
                }
            }
        }

        val viewer = activeViewer
        if (viewer != null) {
            StatusViewerDialog(
                payload = viewer,
                onClose = { activeViewer = null },
                onSaveClick = { statusItem ->
                    viewModel.saveSingleStatus(statusItem)
                    activeViewer = null
                },
                onDeleteClick = { savedItem ->
                    viewModel.deleteSavedItems(listOf(savedItem))
                    activeViewer = null
                },
                onShareClick = {
                    viewModel.shareMedia(
                        uri = viewer.uri,
                        fileName = viewer.title,
                        mimeType = viewer.mimeType
                    )
                },
                onRepostWhatsAppClick = {
                    viewModel.shareMedia(
                        uri = viewer.uri,
                        fileName = viewer.title,
                        mimeType = viewer.mimeType,
                        targetPackage = StatusSourceType.WHATSAPP.packageName
                    )
                },
                onRepostBusinessClick = {
                    viewModel.shareMedia(
                        uri = viewer.uri,
                        fileName = viewer.title,
                        mimeType = viewer.mimeType,
                        targetPackage = StatusSourceType.WHATSAPP_BUSINESS.packageName
                    )
                }
            )
        }
    }
}
