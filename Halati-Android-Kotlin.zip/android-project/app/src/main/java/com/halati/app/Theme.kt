package com.halati.app

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

object HalatiColors {
    val PitchBlack = Color(0xFF050507)
    val SurfaceDark = Color(0xFF0D0F14)
    val SurfaceElevated = Color(0xFF151821)
    val HairlineBorder = Color(0xFF232734)
    val EmeraldPrimary = Color(0xFF10B981)
    val EmeraldDeep = Color(0xFF064E3B)
    val GoldAccent = Color(0xFFD4AF37)
    val TextPrimary = Color(0xFFF4F6F9)
    val TextSecondary = Color(0xFF9CA3AF)
    val TextMuted = Color(0xFF6B7280)
    val DangerRed = Color(0xFFEF4444)
    val WarningAmber = Color(0xFFF59E0B)
}

private val HalatiDarkColorScheme = darkColorScheme(
    primary = HalatiColors.EmeraldPrimary,
    onPrimary = Color(0xFF031A11),
    primaryContainer = HalatiColors.EmeraldDeep,
    onPrimaryContainer = Color(0xFFA7F3D0),
    secondary = HalatiColors.GoldAccent,
    onSecondary = Color(0xFF1C1602),
    background = HalatiColors.PitchBlack,
    onBackground = HalatiColors.TextPrimary,
    surface = HalatiColors.SurfaceDark,
    onSurface = HalatiColors.TextPrimary,
    surfaceVariant = HalatiColors.SurfaceElevated,
    onSurfaceVariant = HalatiColors.TextSecondary,
    outline = HalatiColors.HairlineBorder,
    error = HalatiColors.DangerRed,
    onError = Color.White
)

private val HalatiTypography = Typography(
    headlineMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Bold,
        fontSize = 24.sp,
        lineHeight = 32.sp,
        color = HalatiColors.TextPrimary
    ),
    titleLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.SemiBold,
        fontSize = 19.sp,
        lineHeight = 26.sp,
        color = HalatiColors.TextPrimary
    ),
    titleMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.SemiBold,
        fontSize = 16.sp,
        lineHeight = 22.sp,
        color = HalatiColors.TextPrimary
    ),
    bodyMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Normal,
        fontSize = 14.sp,
        lineHeight = 22.sp,
        color = HalatiColors.TextSecondary
    ),
    labelMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Medium,
        fontSize = 12.sp,
        lineHeight = 16.sp,
        color = HalatiColors.TextSecondary
    ),
    labelSmall = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Medium,
        fontSize = 11.sp,
        lineHeight = 14.sp,
        color = HalatiColors.TextMuted
    )
)

@Composable
fun HalatiTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = HalatiDarkColorScheme,
        typography = HalatiTypography,
        content = content
    )
}
