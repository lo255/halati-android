package com.halati.app

import android.content.Intent
import android.net.Uri
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope

data class FullRefreshSnapshot(
    val whatsappResult: SourceScanResult,
    val businessResult: SourceScanResult,
    val savedItems: List<SavedMediaItem>
)

class StatusRepository(
    private val whatsAppSource: WhatsAppSource,
    private val businessWhatsAppSource: BusinessWhatsAppSource,
    private val storageManager: StorageManager,
    private val mediaRepository: MediaRepository
) {

    suspend fun refreshAll(): FullRefreshSnapshot = coroutineScope {
        val waDeferred = async { whatsAppSource.scanStatuses() }
        val bizDeferred = async { businessWhatsAppSource.scanStatuses() }
        val savedDeferred = async { mediaRepository.loadSavedMedia() }

        val savedItems = savedDeferred.await()
        val savedNamesSet = savedItems.map { it.displayName }.toSet() +
            mediaRepository.getSavedFileNamesIndex()

        val waRaw = waDeferred.await()
        val bizRaw = bizDeferred.await()

        FullRefreshSnapshot(
            whatsappResult = annotateSavedFlags(waRaw, savedNamesSet),
            businessResult = annotateSavedFlags(bizRaw, savedNamesSet),
            savedItems = savedItems
        )
    }

    fun persistSafFolderPermission(source: StatusSourceType, uri: Uri) {
        storageManager.saveSafTreeUri(source, uri)
    }

    fun revokeSafFolderPermission(source: StatusSourceType) {
        storageManager.clearSafTreeUri(source)
    }

    fun isAutoRefreshEnabled(): Boolean = storageManager.getAutoRefreshOnLaunch()

    fun setAutoRefreshEnabled(enabled: Boolean) {
        storageManager.setAutoRefreshOnLaunch(enabled)
    }

    suspend fun saveSingle(item: StatusItem): SaveSingleOutcome {
        return mediaRepository.saveStatus(item)
    }

    suspend fun saveMultiple(items: List<StatusItem>): BatchSaveResult {
        return mediaRepository.saveBatch(items)
    }

    suspend fun deleteSaved(items: List<SavedMediaItem>): DeleteOutcome {
        return mediaRepository.deleteSavedItems(items)
    }

    suspend fun buildShareIntent(
        uri: Uri,
        fileName: String,
        mimeType: String,
        targetPackage: String? = null
    ): Intent? {
        return mediaRepository.createShareIntent(
            uri = uri,
            fileName = fileName,
            mimeType = mimeType,
            targetPackage = targetPackage
        )
    }

    private fun annotateSavedFlags(
        scanResult: SourceScanResult,
        savedNamesSet: Set<String>
    ): SourceScanResult {
        if (scanResult.items.isEmpty()) return scanResult
        val updatedItems = scanResult.items.map { status ->
            val halatiName = MediaRepository.buildHalatiDisplayName(status.source, status.fileName)
            val alreadySaved = status.fileName in savedNamesSet || halatiName in savedNamesSet
            status.copy(isSaved = alreadySaved)
        }
        return scanResult.copy(items = updatedItems)
    }
}
