package com.halati.app

import android.os.Build
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@Composable
fun SettingsScreen(
    uiState: HalatiUiState,
    androidVersionLabel: String,
    onToggleAutoRefresh: (Boolean) -> Unit,
    onRequestSafFolder: (StatusSourceType) -> Unit,
    onRevokeSafFolder: (StatusSourceType) -> Unit,
    onOpenAllFilesSettings: () -> Unit,
    onRequestGalleryPermission: () -> Unit,
    onOpenAppSettings: () -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(HalatiColors.PitchBlack),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            SettingsCard(title = "التحديث التلقائي وسلوك الفحص") {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "تحديث الحالات تلقائياً عند الفتح",
                            style = MaterialTheme.typography.titleMedium
                        )
                        Text(
                            text = "يفحص مجلدات واتساب وواتساب الأعمال فور تشغيل التطبيق دون طلب إعادة اختيار المجلد.",
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                    Switch(
                        checked = uiState.autoRefreshOnLaunch,
                        onCheckedChange = onToggleAutoRefresh,
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color(0xFF031A11),
                            checkedTrackColor = HalatiColors.EmeraldPrimary
                        )
                    )
                }
            }
        }

        item {
            SettingsCard(title = "صلاحيات المجلدات الدائمة (SAF)") {
                SourcePermissionRow(
                    title = "واتساب (com.whatsapp)",
                    scanResult = uiState.whatsappResult,
                    onSelectFolder = { onRequestSafFolder(StatusSourceType.WHATSAPP) },
                    onRevokeFolder = { onRevokeSafFolder(StatusSourceType.WHATSAPP) }
                )
                Spacer(modifier = Modifier.height(12.dp))
                SourcePermissionRow(
                    title = "واتساب الأعمال (com.whatsapp.w4b)",
                    scanResult = uiState.businessResult,
                    onSelectFolder = { onRequestSafFolder(StatusSourceType.WHATSAPP_BUSINESS) },
                    onRevokeFolder = { onRevokeSafFolder(StatusSourceType.WHATSAPP_BUSINESS) }
                )
            }
        }

        item {
            SettingsCard(title = "الوصول المباشر وإعدادات النظام") {
                Text(
                    text = "إصدار النظام الحالي: $androidVersionLabel",
                    style = MaterialTheme.typography.labelMedium,
                    color = HalatiColors.EmeraldPrimary
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "يعتمد تطبيق «حالتي» بشكل أساسي على Storage Access Framework (SAF) لأنه الأسلوب الرسمي المتوافق مع سياسات Google Play على Android 10–16 دون الحاجة لإعادة اختيار المجلد.",
                    style = MaterialTheme.typography.bodyMedium
                )
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "حالة إذن الوصول لجميع الملفات (MANAGE_EXTERNAL_STORAGE): " +
                            if (uiState.hasAllFilesAccess) "مفعّل" else "غير مفعّل (اختياري للاستخدام الشخصي خارج متجر Play)",
                        style = MaterialTheme.typography.labelMedium,
                        color = if (uiState.hasAllFilesAccess) HalatiColors.EmeraldPrimary else HalatiColors.TextSecondary
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedButton(
                        onClick = onOpenAllFilesSettings,
                        border = BorderStroke(1.dp, HalatiColors.HairlineBorder),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "فتح إعدادات الوصول لجميع الملفات",
                            color = HalatiColors.TextPrimary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = onRequestGalleryPermission,
                        border = BorderStroke(1.dp, HalatiColors.HairlineBorder),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(text = "إذن المعرض", color = HalatiColors.TextPrimary)
                    }
                    OutlinedButton(
                        onClick = onOpenAppSettings,
                        border = BorderStroke(1.dp, HalatiColors.HairlineBorder),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(text = "إعدادات التطبيق", color = HalatiColors.TextPrimary)
                    }
                }
            }
        }

        item {
            SettingsCard(title = "مجلد الحفظ ومنع التكرار") {
                Text(
                    text = "يتم حفظ الصور في Pictures/Halati والفيديوهات في Movies/Halati عبر MediaStore، مع فحص بصمة SHA-256 واسم الملف لمنع تكرار الحفظ.",
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }
    }
}

@Composable
private fun SettingsCard(
    title: String,
    content: @Composable () -> Unit
) {
    Surface(
        color = HalatiColors.SurfaceDark,
        shape = RoundedCornerShape(18.dp),
        border = BorderStroke(1.dp, HalatiColors.HairlineBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                color = HalatiColors.TextPrimary
            )
            Spacer(modifier = Modifier.height(4.dp))
            content()
        }
    }
}

@Composable
private fun SourcePermissionRow(
    title: String,
    scanResult: SourceScanResult,
    onSelectFolder: () -> Unit,
    onRevokeFolder: () -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(text = title, style = MaterialTheme.typography.bodyMedium, color = HalatiColors.TextPrimary)
        Text(
            text = "الوضع الحالي: ${scanResult.accessMode.labelAr}",
            style = MaterialTheme.typography.labelMedium,
            color = HalatiColors.TextSecondary
        )
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Button(
                onClick = onSelectFolder,
                colors = ButtonDefaults.buttonColors(
                    containerColor = HalatiColors.EmeraldPrimary,
                    contentColor = Color(0xFF031A11)
                ),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.weight(1f)
            ) {
                Text(text = "تحديد / تغيير المجلد", fontWeight = FontWeight.Bold)
            }
            if (scanResult.accessMode == AccessMode.SAF_PERSISTED) {
                OutlinedButton(
                    onClick = onRevokeFolder,
                    border = BorderStroke(1.dp, HalatiColors.DangerRed.copy(alpha = 0.5f)),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text(text = "إلغاء الربط", color = HalatiColors.DangerRed)
                }
            }
        }
    }
}
