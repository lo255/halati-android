package com.halati.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Test
import java.io.ByteArrayInputStream

class MediaRepositoryTest {

    @Test
    fun `buildHalatiDisplayName prefixes WhatsApp and WhatsApp Business distinctly`() {
        val waName = MediaRepository.buildHalatiDisplayName(StatusSourceType.WHATSAPP, "clip.mp4")
        val bizName = MediaRepository.buildHalatiDisplayName(StatusSourceType.WHATSAPP_BUSINESS, "clip.mp4")

        assertEquals("Halati_WA_clip.mp4", waName)
        assertEquals("Halati_WAB_clip.mp4", bizName)
        assertNotEquals(waName, bizName)
    }

    @Test
    fun `sha256FromStream produces identical digest for duplicate content`() {
        val bytes = "sample-status-binary-payload".toByteArray()
        val firstHash = MediaRepository.sha256FromStream(ByteArrayInputStream(bytes))
        val secondHash = MediaRepository.sha256FromStream(ByteArrayInputStream(bytes))
        val differentHash = MediaRepository.sha256FromStream(ByteArrayInputStream("different".toByteArray()))

        assertEquals(64, firstHash.length)
        assertEquals(firstHash, secondHash)
        assertNotEquals(firstHash, differentHash)
    }
}
