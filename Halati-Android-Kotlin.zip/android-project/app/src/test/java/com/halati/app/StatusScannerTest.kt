package com.halati.app

import android.content.Context
import androidx.documentfile.provider.DocumentFile
import androidx.test.core.app.ApplicationProvider
import io.mockk.every
import io.mockk.mockk
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class StatusScannerTest {

    @get:Rule
    val tempFolder = TemporaryFolder()

    private lateinit var context: Context
    private lateinit var storageManager: StorageManager
    private lateinit var scanner: StatusScanner

    @Before
    fun setup() {
        context = ApplicationProvider.getApplicationContext()
        storageManager = mockk(relaxed = true)
        scanner = StatusScanner(context, storageManager)
    }

    @Test
    fun `isSupportedVisibleMediaName ignores nomedia and dot-hidden files`() {
        assertFalse(StatusScanner.isSupportedVisibleMediaName(".nomedia"))
        assertFalse(StatusScanner.isSupportedVisibleMediaName(".hidden.jpg"))
        assertFalse(StatusScanner.isSupportedVisibleMediaName("nomedia"))
        assertFalse(StatusScanner.isSupportedVisibleMediaName("notes.txt"))
        assertTrue(StatusScanner.isSupportedVisibleMediaName("IMG_2026_01.jpg"))
        assertTrue(StatusScanner.isSupportedVisibleMediaName("VID_2026_02.mp4"))
        assertTrue(StatusScanner.isSupportedVisibleMediaName("PHOTO.WEBP"))
    }

    @Test
    fun `scanFileDirectory ignores empty files and nomedia and separates images from videos`() {
        val statusesDir = File(tempFolder.root, ".Statuses").apply { mkdirs() }
        File(statusesDir, ".nomedia").writeText("")
        File(statusesDir, "empty.jpg").writeBytes(ByteArray(0))
        File(statusesDir, "status_photo.jpg").writeBytes(byteArrayOf(1, 2, 3, 4))
        File(statusesDir, "status_video.mp4").writeBytes(byteArrayOf(5, 6, 7, 8, 9))

        val items = scanner.scanFileDirectory(statusesDir, StatusSourceType.WHATSAPP)

        assertEquals(2, items.size)
        val images = items.filter { it.mediaType == MediaType.IMAGE }
        val videos = items.filter { it.mediaType == MediaType.VIDEO }
        assertEquals(1, images.size)
        assertEquals(1, videos.size)
        assertEquals("status_photo.jpg", images.first().fileName)
        assertEquals("status_video.mp4", videos.first().fileName)
    }

    @Test
    fun `scanSource returns FOLDER_NOT_FOUND_OR_EMPTY when SAF folder has only nomedia`() = runTest {
        val nomediaFile = mockk<DocumentFile>(relaxed = true) {
            every { isDirectory } returns false
            every { name } returns ".nomedia"
            every { length() } returns 0L
        }
        val safDir = mockk<DocumentFile>(relaxed = true) {
            every { listFiles() } returns arrayOf(nomediaFile)
        }
        every { storageManager.resolveAccessMode(StatusSourceType.WHATSAPP) } returns AccessMode.SAF_PERSISTED
        every { storageManager.resolveSafStatusesDirectory(StatusSourceType.WHATSAPP) } returns safDir

        val result = scanner.scanSource(StatusSourceType.WHATSAPP, isAppInstalled = true)

        assertEquals(SourceAccessState.FOLDER_NOT_FOUND_OR_EMPTY, result.accessState)
        assertTrue(result.items.isEmpty())
    }

    @Test
    fun `scanSource returns NEEDS_FOLDER_PERMISSION when no SAF URI and no All-Files access`() = runTest {
        every { storageManager.resolveAccessMode(StatusSourceType.WHATSAPP_BUSINESS) } returns AccessMode.NONE

        val result = scanner.scanSource(StatusSourceType.WHATSAPP_BUSINESS, isAppInstalled = true)

        assertEquals(SourceAccessState.NEEDS_FOLDER_PERMISSION, result.accessState)
        assertEquals(AccessMode.NONE, result.accessMode)
    }
}
