package com.halati.app

import android.net.Uri
import io.mockk.coEvery
import io.mockk.mockk
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class StatusRepositoryTest {

    @Test
    fun `refreshAll marks status items as saved when matching Halati gallery display name exists`() = runTest {
        val waSource = mockk<WhatsAppSource>()
        val bizSource = mockk<BusinessWhatsAppSource>()
        val storageManager = mockk<StorageManager>(relaxed = true)
        val mediaRepository = mockk<MediaRepository>()

        val itemSaved = StatusItem(
            id = "WHATSAPP_img1.jpg",
            uri = Uri.parse("content://example/img1.jpg"),
            fileName = "img1.jpg",
            mimeType = "image/jpeg",
            mediaType = MediaType.IMAGE,
            source = StatusSourceType.WHATSAPP,
            sizeBytes = 1024L,
            lastModifiedMillis = 1000L
        )
        val itemUnsaved = itemSaved.copy(
            id = "WHATSAPP_img2.jpg",
            fileName = "img2.jpg"
        )

        coEvery { waSource.scanStatuses() } returns SourceScanResult(
            source = StatusSourceType.WHATSAPP,
            accessState = SourceAccessState.READY,
            accessMode = AccessMode.SAF_PERSISTED,
            items = listOf(itemSaved, itemUnsaved)
        )
        coEvery { bizSource.scanStatuses() } returns SourceScanResult(
            source = StatusSourceType.WHATSAPP_BUSINESS,
            accessState = SourceAccessState.FOLDER_NOT_FOUND_OR_EMPTY,
            accessMode = AccessMode.SAF_PERSISTED
        )
        coEvery { mediaRepository.loadSavedMedia() } returns listOf(
            SavedMediaItem(
                id = 1L,
                uri = Uri.parse("content://media/external/images/media/1"),
                displayName = "Halati_WA_img1.jpg",
                mimeType = "image/jpeg",
                mediaType = MediaType.IMAGE,
                sizeBytes = 1024L,
                dateAddedMillis = 2000L
            )
        )
        coEvery { mediaRepository.getSavedFileNamesIndex() } returns setOf("Halati_WA_img1.jpg")

        val repository = StatusRepository(waSource, bizSource, storageManager, mediaRepository)
        val snapshot = repository.refreshAll()

        val resultItems = snapshot.whatsappResult.items
        assertTrue(resultItems.first { it.fileName == "img1.jpg" }.isSaved)
        assertFalse(resultItems.first { it.fileName == "img2.jpg" }.isSaved)
    }
}
