# تطبيق «حالتي» (Halati) — مشروع Android Kotlin + Jetpack Compose

تطبيق أندرويد أصلي متكامل لحفظ وعرض ومشاركة وإعادة نشر حالات **واتساب** (`com.whatsapp`) و**واتساب الأعمال** (`com.whatsapp.w4b`) على أنظمة **Android 10 (API 29)** إلى **Android 16 (API 36)**.

---

## 1. المتطلبات الأساسية قبل البناء
- **Android Studio**: إصدار **Meerkat / Narwhal** أو أحدث.
- **JDK**: الإصدار **17** (متوافق مع `JvmTarget.JVM_17` في `app/build.gradle.kts`).
- **Android SDK**:
  - `compileSdk = 36` (Android 16)
  - `targetSdk = 36` (Android 16)
  - `minSdk = 29` (Android 10)
- **Gradle**: الإصدار `8.11.1` (محدد في `gradle/wrapper/gradle-wrapper.properties`).

---

## 2. البنية المعمارية وملفات المشروع (`com.halati.app`)
- `MainActivity.kt` — نقطة الدخول الرئيسية بواجهة RTL كاملة، ودعم `enableEdgeToEdge`، و5 تبويبات: **الرئيسية**، **واتساب**، **واتساب الأعمال**، **المحفوظات**، **الإعدادات**.
- `Theme.kt` — تصميم OLED أسود فخم (`#050507`) مع أخضر زمردي (`#10B981`) وذهبي (`#D4AF37`).
- `StatusModels.kt` — نماذج البيانات، حالات الوصول للمصادر، و`HalatiUiState`.
- `PermissionManager.kt` — إدارة صلاحيات Android 10–16:
  - `READ_EXTERNAL_STORAGE` (Android 10–12)
  - `READ_MEDIA_IMAGES` و`READ_MEDIA_VIDEO` (Android 13+)
  - `READ_MEDIA_VISUAL_USER_SELECTED` (Android 14–16)
  - `MANAGE_EXTERNAL_STORAGE` (اختياري عبر إعدادات النظام)
  - بناء `Intent` لمحدد المجلدات SAF موجهاً إلى `Android/media/com.whatsapp/WhatsApp/Media/.Statuses` و`com.whatsapp.w4b`.
- `StorageManager.kt` — حفظ صلاحية `SAF Tree URI` بشكل دائم عبر `takePersistableUriPermission` والاحتفاظ بها بعد إعادة تشغيل التطبيق دون إجبار المستخدم على إعادة اختيار المجلد.
- `WhatsAppSource.kt` و`BusinessWhatsAppSource.kt` — التحقق من تثبيت الحزم وفحص الحالات لكل مصدر.
- `StatusScanner.kt` — فحص مجلدات `.Statuses` المخفية عبر `DocumentFile` أو `File`، وتجاهل `.nomedia` والملفات الفارغة، وفصل الصور عن الفيديوهات، واستخراج مدة الفيديو عبر `MediaMetadataRetriever`.
- `MediaRepository.kt` — الحفظ داخل مجلدي `Pictures/Halati` و`Movies/Halati` عبر `MediaStore` (`IS_PENDING` + `RELATIVE_PATH`)، ومنع التكرار ببصمة **SHA-256**، والحذف عبر `MediaStore.createDeleteRequest` على Android 11+، والمشاركة وإعادة النشر عبر `FileProvider`.
- `StatusRepository.kt` و`StatusViewModel.kt` — تنسيق الفحص التلقائي، التحديث اليدوي، التحديد المتعدد، والحفظ الدفعي.
- `HomeScreen.kt`، `StatusesScreen.kt`، `SavedScreen.kt`، `SettingsScreen.kt`، `StatusViewer.kt`، `Components.kt` — شاشات التطبيق، عارض الصور بالتكبير، ومشغّل الفيديو المدمج (`Media3 ExoPlayer`).
- `app/src/test/java/com/halati/app/` — اختبارات وحدة (`StatusScannerTest`, `MediaRepositoryTest`, `StatusRepositoryTest`).

---

## 3. طريقة بناء APK (Debug و Release)

### الطريقة الأولى: عبر Android Studio
1. فك ضغط `Halati-Android-Kotlin.zip` ليظهر مجلد `android-project`.
2. من Android Studio اختر **File → Open** وحدد مجلد `android-project`.
3. انتظر انتهاء مزامنة **Gradle Sync** وتنزيل المكتبات من Google/Maven Central.
4. لبناء **Debug APK**:
   - من القائمة العلوية: **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. لبناء **Release APK**:
   - من القائمة العلوية: **Build → Generate Signed Bundle / APK...** واختر **APK** ومفتاح التوقيع الخاص بك (أو `assembleRelease` للتجربة الموقّعة بمفتاح debug المحلي).

### الطريقة الثانية: عبر سطر الأوامر (Gradle CLI)
> ملاحظة: إذا لم تكن ملفات `gradlew` موجودة محلياً بعد فك الضغط، شغّل أولاً `gradle wrapper --gradle-version 8.11.1` أو افتح المشروع في Android Studio ليولّدها تلقائياً.

```bash
cd android-project

# 1. تشغيل اختبارات الوحدة (فحص الملفات وتجاهل .nomedia ومنع التكرار)
./gradlew testDebugUnitTest

# 2. بناء Debug APK
./gradlew assembleDebug

# 3. بناء Release APK (مع R8/ProGuard)
./gradlew assembleRelease
```

مسارات ملفات APK الناتجة:
- Debug: `app/build/outputs/apk/debug/app-debug.apk`
- Release: `app/build/outputs/apk/release/app-release.apk`

---

## 4. التحقق العملي على جهاز Android فعلي (Android 10 – Android 16)
1. ثبّت التطبيق على الهاتف:
   ```bash
   adb install -r app/build/outputs/apk/debug/app-debug.apk
   ```
2. افتح تطبيق **واتساب** أو **واتساب الأعمال** وشاهد صورة وفيديو واحد على الأقل حتى يتم تخزينهما في مجلد `.Statuses`.
3. افتح تطبيق **«حالتي»** واضغط **«تحديد مجلد حالات واتساب (SAF)»** واختر **«استخدام هذا المجلد»** مرة واحدة فقط.
4. أغلق التطبيق نهائياً ثم أعد فتحه: ستظهر الحالات تلقائياً عبر الصلاحية المحفوظة دون مطالبتك باختيار المجلد مجدداً.
5. جرّب حفظ صورة وفيديو، وتحقق من ظهورهما في معرض الهاتف داخل مجلد **Halati** (`Pictures/Halati` و`Movies/Halati`)، وتأكد من عدم تكرارهما عند محاولة الحفظ مرة أخرى.
